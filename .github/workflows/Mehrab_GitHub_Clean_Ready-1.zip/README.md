# مهراب — اپلیکیشن حسابداری اندروید

پروژه اندرویدی آماده ساخت است.

## ساخت APK بدون Android Studio
این Repository شامل GitHub Actions است. پس از Push شدن روی شاخه `main`، یا با اجرای دستی Workflow، APK در بخش Artifacts قرار می‌گیرد.

مسیر خروجی:
`app/build/outputs/apk/debug/app-debug.apk`

شناسه برنامه:
`com.mehrab.accounting`
